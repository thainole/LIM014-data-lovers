// estas funciones son de ejemplo
//métodos 
export const example = () => {
  return 'example';
};

export const anotherExample = () => {
  return 'OMG';
};

