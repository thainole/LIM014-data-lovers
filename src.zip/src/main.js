// import { example } from './data.js';
import data from './data/athletes/athletes.js';

const athletesData = data.athletes;
console.log(athletesData[0]); //para que me pinte toda la data
